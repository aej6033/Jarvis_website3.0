#include <iostream>

//this is a simple c++ program that prints "Hello World to the command line"
int main(int argc, char* argv[]){
    std::cout << "Hello World!" << std::endl;
}